
# Alumini System
Simple Alumini System using CodeIgniter

Admin User

Email : email@gmail.com

Password : admin


```Currently under development```
