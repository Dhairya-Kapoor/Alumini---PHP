<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Dhairya Kapoor
 * @version : 1.1
 * @since : 21 January 2019
 */
class meetings extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('meetings_model');
        $this->isLoggedIn();   
    }

    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        redirect("meetingListing");
    }

    /**
     * This function is used to load the meetings list
     */
    function meetingListing()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $searchText = $this->input->post('searchText');
            $searchconferenceId = $this->input->post('conferenceId');
            $searchmeetingSizeId = $this->input->post('sizeId');
            $data['searchText'] = $searchText;
            $data['searchconferenceId'] = $searchconferenceId;
            $data['searchmeetingSizeId'] = $searchmeetingSizeId;
            $data['meetingSizes'] = $this->meetings_model->getmeetingSizes();
            $data['conferences'] = $this->meetings_model->getconferences();
            
            $this->load->library('pagination');
            
            $count = $this->meetings_model->meetingListingCount($searchText, $searchconferenceId, $searchmeetingSizeId);

			$returns = $this->paginationCompress ( "meetingListing/", $count, 5 );
            
            $data['meetingRecords'] = $this->meetings_model->meetingListing($searchText, $searchconferenceId, $searchmeetingSizeId, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'DigiLodge : meeting Listing';
            
            $this->loadViews("meetings/meetingIndex", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function addNewmeeting()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
        	$data['meetingSizes'] = $this->meetings_model->getmeetingSizes();
        	$data['conferences'] = $this->meetings_model->getconferences();

            $this->global['pageTitle'] = 'DigiLodge : Add New meeting';

            $this->loadViews("meetings/addNewmeeting", $this->global, $data, NULL);
        }
    }


    /**
     * This function is used to add new meeting to the system
     */
    function addedNewmeeting()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('conferenceId','conference','required|xss_clean');
            $this->form_validation->set_rules('sizeId','meeting Size','required|xss_clean');
            $this->form_validation->set_rules('meetingNumber','meeting Number','trim|required|xss_clean');

            if($this->form_validation->run() == FALSE)
            {
                $this->addNewmeeting();
            }
            else
            {
                $conferenceId = $this->input->post('conferenceId');
                $sizeId = $this->input->post('sizeId');
                $meetingNumber = $this->input->post('meetingNumber');
                
                $meetingInfo = array('conferenceId'=>$conferenceId, 'meetingSizeId'=>$sizeId, 'meetingNumber'=>$meetingNumber,
                	'createdBy'=>$this->vendorId, 'createdDtm'=>date('Y-m-d H:i:sa'));
                
                $result = $this->meetings_model->addedNewmeeting($meetingInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New meeting created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'meeting creation failed');
                }
                
                redirect('addNewmeeting');
            }
        }
    }

    /**
     * This function is used load user edit information
     * @param number $userId : Optional : This is user id
     */
    function editOldmeeting($meetingId = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($meetingId == null)
            {
                redirect('meetingListing');
            }

            $data['conferences'] = $this->meetings_model->getconferences();
            $data['meetingSizes'] = $this->meetings_model->getmeetingSizes();
            
            $data['meetingInfo'] = $this->meetings_model->getmeetingInfo($meetingId);
            
            $this->global['pageTitle'] = 'DigiLodge : Edit meeting';
            
            $this->loadViews("meetings/editOldmeeting", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to edit the user information
     */
    function updateOldmeeting()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $meetingId = $this->input->post('meetingId');

            $this->form_validation->set_rules('conferenceId','conference','required|xss_clean');
            $this->form_validation->set_rules('sizeId','meeting Size','required|xss_clean');
            $this->form_validation->set_rules('meetingNumber','meeting Number','trim|required|xss_clean');

            if($this->form_validation->run() == FALSE)
            {
                $this->editOldmeetingSize($meetingSizeId);
            }
            else
            {                
                $sizeId = $this->input->post('sizeId');
                $conferenceId = $this->input->post('conferenceId');
                $meetingNumber = $this->input->post('meetingNumber');
                
                $meetingInfo = array('conferenceId'=>$conferenceId, 'meetingSizeId'=>$sizeId, 'meetingNumber'=>$meetingNumber,
                    'createdBy'=>$this->vendorId, 'createdDtm'=>date('Y-m-d H:i:sa'));
                
                $result = $this->meetings_model->updateOldmeeting($meetingInfo, $meetingId);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'meeting updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'meeting updation failed');
                }

                redirect('meetingListing');
            }
        }
    }

    /**
     * This function is used to delete the user using userId
     * @return boolean $result : TRUE / FALSE
     */
    function deletemeeting()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $meetingId = $this->input->post('meetingId');
            $meetingInfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:sa'));
            
            $result = $this->meetings_model->deletemeeting($meetingId, $meetingInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}