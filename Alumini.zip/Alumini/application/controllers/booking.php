<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : Booking (BookingController)
 * Booking Class to control all booking related operations.
 * @author : Dhairya Kapoor
 * @version : 1.1
 * @since : 26 January 2019
 */
class Booking extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Booking_model', "booking");
        $this->load->model('meetings_model');
        $this->isLoggedIn();   
    }

    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        redirect("book");
    }

    /**
     * This function is used to load the meetings list
     */
    function bookings()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $searchText = $this->input->post('searchText');
            $searchconferenceId = $this->input->post('conferenceId');
            $searchmeetingSizeId = $this->input->post('sizeId');
            $searchmeetingId = $this->input->post('meetingId');
            $data['searchText'] = $searchText;
            $data['searchmeetingId'] = $searchmeetingId;
            $data['searchconferenceId'] = $searchconferenceId;
            $data['searchmeetingSizeId'] = $searchmeetingSizeId;
            $data['meetings'] = $this->meetings_model->getmeetings();
            $data['meetingSizes'] = $this->meetings_model->getmeetingSizes();
            $data['conferences'] = $this->meetings_model->getconferences();

            $this->load->library('pagination');
            
            $count = $this->booking->bookingCount($searchText, $searchmeetingId, $searchconferenceId, $searchmeetingSizeId);

			$returns = $this->paginationCompress ( "book/", $count, 10);
            
            $data['bookingRecords'] = $this->booking->bookingListing($searchText, $searchmeetingId, $searchconferenceId, $searchmeetingSizeId, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'DigiLodge : Bookings';
            
            $this->loadViews("bookings/bookingIndex", $this->global, $data, NULL);
        }
    }

    /**
     * This function is used to load the add new form
     */
    function addNewBooking()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->global['pageTitle'] = 'DigiLodge : Book the meeting';
            $data = [];

            $this->loadViews("bookings/addNewBooking", $this->global, $data, NULL);
        }
    }
}