<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Dhairya Kapoor
 * @version : 1.1
 * @since : 25 January 2019
 */
class student extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('student_model', 'student');
        $this->isLoggedIn();   
    }
    
    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        redirect('studentListing');
    }
    
    /**
     * This function is used to load the user list
     */
    function studentListing()
    {
        $searchText = $this->input->post('searchText');

        $data['searchText'] = $searchText;
        
        $this->load->library('pagination');
        
        $count = $this->student->studentListingCount($searchText);

        $returns = $this->paginationCompress ( "studentListing/", $count, 5 );
        
        $data['studentRecords'] = $this->student->studentListing($searchText, $returns["page"], $returns["segment"]);
        
        $this->global['pageTitle'] = 'DigiLodge : student Listing';
        
        $this->loadViews("student/studentIndex", $this->global, $data, NULL);
    }

    /**
     * This function is used to load the add new form
     */
    function addNewstudent()
    {
        $this->global['pageTitle'] = 'DigiLodge : Add New student';
        $this->loadViews("student/addNewstudent", $this->global, NULL, NULL);
    }
    
    /**
     * This function is used to add new user to the system
     */
    function addedNewstudent()
    {
        $this->load->library('form_validation');
            
        $this->form_validation->set_rules('studentName','student Name','trim|required|max_length[50]|xss_clean');
        $this->form_validation->set_rules('studentEmail','student Email','trim|valid_email|xss_clean|max_length[128]');
        $this->form_validation->set_rules('studentAddress','student Address','max_length[1024]|xss_clean');
        $this->form_validation->set_rules('studentPhone','student Phone','trim|max_length[15]|numeric');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->addNewstudent();
        }
        else
        {
            $studentName = ucwords(strtolower($this->input->post('studentName')));
            $studentEmail = $this->input->post('studentEmail');
            $studentAddress = $this->input->post('studentAddress');
            $studentPhone = $this->input->post('studentPhone');
            
            $studentInfo = array('studentName'=>$studentName, 'studentEmail'=>$studentEmail, 'studentAddress'=>$studentAddress,
                                'studentPhone'=>$studentPhone, 'createdBy'=>$this->vendorId, 'createdDtm'=>date('Y-m-d H:i:sa'));
            
            $result = $this->student->addNewstudent($studentInfo);
            
            if($result > 0)
            {
                $this->session->set_flashdata('success', 'New student created successfully');
            }
            else
            {
                $this->session->set_flashdata('error', 'student creation failed');
            }
            
            redirect('addNewstudent');
        }
    }

    
    /**
     * This function is used load user edit information
     * @param number $userId : Optional : This is user id
     */
    function editOldstudent($studentId = NULL)
    {
        if($studentId == null)
        {
            redirect('studentListing');
        }
        
        $data['studentInfo'] = $this->student->getstudentInfo($studentId);
        
        $this->global['pageTitle'] = 'DigiLodge : Edit student';
        
        $this->loadViews("student/editOldstudent", $this->global, $data, NULL);
    }
    
    
    /**
     * This function is used to edit the user information
     */
    function updateOldstudent()
    {
        $this->load->library('form_validation');
            
        $studentId = $this->input->post('studentId');
        
        $this->form_validation->set_rules('studentName','student Name','trim|required|max_length[50]|xss_clean');
        $this->form_validation->set_rules('studentEmail','student Email','trim|valid_email|xss_clean|max_length[128]');
        $this->form_validation->set_rules('studentAddress','student Address','max_length[1024]|xss_clean');
        $this->form_validation->set_rules('studentPhone','student Phone','trim|max_length[15]|numeric');
        
        if($this->form_validation->run() == FALSE)
        {
            $this->editOldstudent($studentId);
        }
        else
        {
            $studentName = ucwords(strtolower($this->input->post('studentName')));
            $studentEmail = $this->input->post('studentEmail');
            $studentAddress = $this->input->post('studentAddress');
            $studentPhone = $this->input->post('studentPhone');
            
            $studentInfo = array('studentName'=>$studentName, 'studentEmail'=>$studentEmail, 'studentAddress'=>$studentAddress,
                                'studentPhone'=>$studentPhone, 'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:sa'));
            
            $result = $this->student->updateOldstudent($studentInfo, $studentId);
            
            if($result == true)
            {
                $this->session->set_flashdata('success', 'student updated successfully');
            }
            else
            {
                $this->session->set_flashdata('error', 'student updation failed');
            }
            
            redirect('student');
        }
    }


    /**
     * This function is used to delete the student using studentId
     * @return boolean $result : TRUE / FALSE
     */
    function deletestudent()
    {
        $studentId = $this->input->post('studentId');
        $studentInfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:sa'));
        
        $result = $this->student->deletestudent($studentId, $studentInfo);
        
        if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
        else { echo(json_encode(array('status'=>FALSE))); }
    }
}

?>