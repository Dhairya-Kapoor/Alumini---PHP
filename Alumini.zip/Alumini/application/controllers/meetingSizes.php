<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : User (UserController)
 * User Class to control all user related operations.
 * @author : Dhairya Kapoor
 * @version : 1.1
 * @since : 15 January 2019
 */
class meetingSizes extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('meetingSizes_model');
        $this->isLoggedIn();   
    }

    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        redirect("meetingSizeListing");
    }

    /**
     * This function is used to load the conferences list
     */
    function meetingSizesListing()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->meetingSizes_model->meetingSizeListingCount($searchText);

			$returns = $this->paginationCompress ( "meetingSizeListing/", $count, 5 );
            
            $data['meetingSizesRecords'] = $this->meetingSizes_model->meetingSizeListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'DigiLodge : meeting Size Listing';
            
            $this->loadViews("meetingSizes/meetingSizeIndex", $this->global, $data, NULL);
        }
    }


    /**
     * This function is used to load the add new form
     */
    function addNewmeetingSize()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->global['pageTitle'] = 'DigiLodge : Add New meeting Size';

            $this->loadViews("meetingSizes/addNewmeetingSize", $this->global, NULL, NULL);
        }
    }
    
    /**
     * This function is used to add new user to the system
     */
    function addedNewmeetingSize()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('sizeTitle','meeting Size Title','trim|required|max_length[256]|xss_clean');
            $this->form_validation->set_rules('sizeDescription','meeting Size Description','trim|required|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNewmeetingSize();
            }
            else
            {
                $meetingSizeTitle = $this->input->post('sizeTitle');
                $meetingSizeDescription = $this->input->post('sizeDescription');
                
                $meetingSizeInfo = array('sizeTitle'=>$meetingSizeTitle, 'sizeDescription'=>$meetingSizeDescription,
                	'createdBy'=>$this->vendorId, 'createdDtm'=>date('Y-m-d H:i:sa'));
                
                $result = $this->meetingSizes_model->addedNewmeetingSize($meetingSizeInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New meeting Size created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'meeting Size creation failed');
                }
                
                redirect('addNewmeetingSize');
            }
        }
    }

    
    /**
     * This function is used load user edit information
     * @param number $userId : Optional : This is user id
     */
    function editOldmeetingSize($meetingSizeId = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($meetingSizeId == null)
            {
                redirect('meetingSizeListing');
            }
            
            $data['meetingSizeInfo'] = $this->meetingSizes_model->getmeetingSizeInfo($meetingSizeId);
            
            $this->global['pageTitle'] = 'DigiLodge : Edit meeting Size';
            
            $this->loadViews("meetingSizes/editOldmeetingSize", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the user information
     */
    function updateOldmeetingSize()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $meetingSizeId = $this->input->post('sizeId');

            $this->form_validation->set_rules('sizeTitle','meeting Size Title','trim|required|max_length[256]|xss_clean');
            $this->form_validation->set_rules('sizeDescription','meeting Size Description','trim|required|xss_clean');
            
            
            if($this->form_validation->run() == FALSE)
            {
                $this->editOldmeetingSize($meetingSizeId);
            }
            else
            {
                $meetingSizeTitle = $this->input->post('sizeTitle');
                $meetingSizeDescription = $this->input->post('sizeDescription');
                
                $meetingSizeInfo = array();

                $meetingSizeInfo = array('sizeTitle'=>$meetingSizeTitle, 'sizeDescription'=>$meetingSizeDescription,
                	'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:sa'));
                
                $result = $this->meetingSizes_model->updateOldmeetingSize($meetingSizeInfo, $meetingSizeId);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', ' updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'meeting Size updation failed');
                }
                
                redirect('meetingSizesListing');
            }
        }
    }

    /**
     * This function is used to delete the user using userId
     * @return boolean $result : TRUE / FALSE
     */
    function deletemeetingSize()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $meetingSizeId = $this->input->post('sizeId');
            $meetingSizeInfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:sa'));
            
            $result = $this->meetingSizes_model->deletemeetingSize($meetingSizeId, $meetingSizeInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }
}