<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';

/**
 * Class : conferences (conferencesController)
 * conferences Class to control all conference related operations.
 * @author : Dhairya Kapoor
 * @version : 1.1
 * @since : 24 January 2019
 */
class conferences extends BaseController
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('conferences_model');
        $this->isLoggedIn();   
    }

    /**
     * This function used to load the first screen of the user
     */
    public function index()
    {
        redirect("conferencesListing");
    }

    /**
     * This function is used to load the conferences list
     */
    function conferencesListing()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $searchText = $this->input->post('searchText');
            $data['searchText'] = $searchText;
            
            $this->load->library('pagination');
            
            $count = $this->conferences_model->conferencesListingCount($searchText);

			$returns = $this->paginationCompress ( "conferencesListing/", $count, 5 );
            
            $data['conferencesRecords'] = $this->conferences_model->conferencesListing($searchText, $returns["page"], $returns["segment"]);
            
            $this->global['pageTitle'] = 'DigiLodge : conferences Listing';
            
            $this->loadViews("conferences/conferences", $this->global, $data, NULL);
        }
    }


    /**
     * This function is used to load the add new form
     */
    function addNewconference()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->global['pageTitle'] = 'DigiLodge : Add New conference';

            $this->loadViews("conferences/addNewconference", $this->global, NULL, NULL);
        }
    }
    
    /**
     * This function is used to add new user to the system
     */
    function addedNewconference()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $this->form_validation->set_rules('conferenceName','conference Name','trim|required|max_length[50]|xss_clean');
            $this->form_validation->set_rules('conferenceCode','conference Code','trim|required|xss_clean|max_length[10]');
            $this->form_validation->set_rules('conferenceDescription','conference Description','required|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->addNewconference();
            }
            else
            {
                $conferenceName = ucwords(strtolower($this->input->post('conferenceName')));
                $conferenceCode = strtoupper($this->input->post('conferenceCode'));
                $conferenceDescription = $this->input->post('conferenceDescription');
                
                $conferenceInfo = array('conferenceName'=>$conferenceName, 'conferenceCode'=>$conferenceCode, 'conferenceDescription'=>$conferenceDescription,
                	'createdBy'=>$this->vendorId, 'createdDtm'=>date('Y-m-d H:i:sa'));
                
                $result = $this->conferences_model->addedNewconference($conferenceInfo);
                
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'New conference created successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'conference creation failed');
                }
                
                redirect('addNewconference');
            }
        }
    }

    
    /**
     * This function is used load user edit information
     * @param number $userId : Optional : This is user id
     */
    function editOldconference($conferenceId = NULL)
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            if($conferenceId == null)
            {
                redirect('conferencesListing');
            }
            
            $data['conferenceInfo'] = $this->conferences_model->getconferenceInfo($conferenceId);
            
            $this->global['pageTitle'] = 'DigiLodge : Edit conference';
            
            $this->loadViews("conferences/editOldconference", $this->global, $data, NULL);
        }
    }
    
    
    /**
     * This function is used to edit the user information
     */
    function updateOldconference()
    {
        if($this->isAdmin() == TRUE)
        {
            $this->loadThis();
        }
        else
        {
            $this->load->library('form_validation');
            
            $conferenceId = $this->input->post('conferenceId');
            
            $this->form_validation->set_rules('conferenceName','conference Name','trim|required|max_length[50]|xss_clean');
            $this->form_validation->set_rules('conferenceCode','conference Code','trim|required|xss_clean|max_length[10]');
            $this->form_validation->set_rules('conferenceDescription','conference Description','required|xss_clean');
            
            if($this->form_validation->run() == FALSE)
            {
                $this->editOldconference($conferenceId);
            }
            else
            {
                $conferenceName = ucwords(strtolower($this->input->post('conferenceName')));
                $conferenceCode = strtoupper($this->input->post('conferenceCode'));
                $conferenceDescription = $this->input->post('conferenceDescription');
                
                $conferenceInfo = array();
                
                $conferenceInfo = array('conferenceName'=>$conferenceName, 'conferenceCode'=>$conferenceCode, 'conferenceDescription'=>$conferenceDescription,
                	'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:sa'));

                $result = $this->conferences_model->updateOldconference($conferenceInfo, $conferenceId);
                
                if($result == true)
                {
                    $this->session->set_flashdata('success', 'conference updated successfully');
                }
                else
                {
                    $this->session->set_flashdata('error', 'conference updation failed');
                }
                
                redirect('conferencesListing');
            }
        }
    }

    /**
     * This function is used to delete the user using userId
     * @return boolean $result : TRUE / FALSE
     */
    function deleteconferences()
    {
        if($this->isAdmin() == TRUE)
        {
            echo(json_encode(array('status'=>'access')));
        }
        else
        {
            $conferencesId = $this->input->post('conferencesId');
            $conferencesInfo = array('isDeleted'=>1,'updatedBy'=>$this->vendorId, 'updatedDtm'=>date('Y-m-d H:i:sa'));
            
            $result = $this->conferences_model->deleteconferences($conferencesId, $conferencesInfo);
            
            if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
            else { echo(json_encode(array('status'=>FALSE))); }
        }
    }

}