<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : meetings_model 
 * meetings model to handle database operations related to meetings
 * @author : Dhairya Kapoor
 * @version : 1.1
 * @since : 15 Jan 2019
 */
class meetings_model extends CI_Model
{
	/**
     * This function is used to get the conference listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function meetingListingCount($searchText, $searchconferenceId, $searchmeetingSizeId)
    {
        $this->db->select('BaseTbl.meetingId, BaseTbl.meetingNumber, BaseTbl.meetingSizeId, RS.sizeTitle, RS.sizeDescription,
        					BaseTbl.conferenceId, FR.conferenceName, FR.conferenceCode');
        $this->db->from('ldg_meetings AS BaseTbl');
        $this->db->join('ldg_meeting_sizes AS RS', 'RS.sizeId = BaseTbl.meetingSizeId');
        $this->db->join('ldg_conference AS FR', 'FR.conferenceId = BaseTbl.conferenceId');
        $this->db->where('BaseTbl.isDeleted', 0);
        if(!empty($searchText)){
            $this->db->where('BaseTbl.meetingNumber LIKE "%'.$searchText.'%" OR RS.sizeDescription LIKE "%'.$searchText.'%"');
        }
        if(!empty($searchconferenceId)){
            $this->db->where('BaseTbl.conferenceId', $searchconferenceId);
        }
        if(!empty($searchmeetingSizeId)){
            $this->db->where('BaseTbl.meetingSizeId', $searchmeetingSizeId);
        }
        $this->db->order_by('BaseTbl.meetingId', "DESC");
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the conference listing
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function meetingListing($searchText, $searchconferenceId, $searchmeetingSizeId, $page, $segment)
    {
        $this->db->select('BaseTbl.meetingId, BaseTbl.meetingNumber, BaseTbl.meetingSizeId, RS.sizeTitle, RS.sizeDescription,
        					BaseTbl.conferenceId, FR.conferenceName, FR.conferenceCode');
        $this->db->from('ldg_meetings AS BaseTbl');
        $this->db->join('ldg_meeting_sizes AS RS', 'RS.sizeId = BaseTbl.meetingSizeId');
        $this->db->join('ldg_conference AS FR', 'FR.conferenceId = BaseTbl.conferenceId');
        $this->db->where('BaseTbl.isDeleted', 0);
        if(!empty($searchText)){
            $this->db->where('BaseTbl.meetingNumber LIKE "%'.$searchText.'%" OR RS.sizeDescription LIKE "%'.$searchText.'%"');
        }
        if(!empty($searchconferenceId)){
            $this->db->where('BaseTbl.conferenceId', $searchconferenceId);
        }
        if(!empty($searchmeetingSizeId)){
            $this->db->where('BaseTbl.meetingSizeId', $searchmeetingSizeId);
        }
        $this->db->order_by('BaseTbl.meetingId', "DESC");
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();
        return $result;
    }

    /**
     * This function is used to get all meeting sizes
     */
    function getmeetingSizes()
    {
    	$this->db->select('sizeId, sizeTitle, sizeDescription');
        $this->db->from('ldg_meeting_sizes');
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();

        return $query->result();
    }

    /**
     * This function is used to get all conferences
     */
    function getconferences()
    {
    	$this->db->select('conferenceId, conferenceName, conferenceCode');
        $this->db->from('ldg_conference');
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();
        
        return $query->result();
    }

    /**
     * This function is used to add new meeting to system
     * @param array $meetingInfo : This is meeting information
     * @return number $insert_id : This is last inserted id
     */
    function addedNewmeeting($meetingInfo)
    {
        $this->db->trans_start();
        $this->db->insert('ldg_meetings', $meetingInfo);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        
        return $insert_id;
    }

    /**
     * This function used to get conference information by id
     * @param number $meetingId : This is conference id
     * @return array $result : This is conference information
     */
    function getmeetingInfo($meetingId)
    {
        $this->db->select('meetingId, meetingNumber, meetingSizeId, conferenceId');
        $this->db->from('ldg_meetings');
        $this->db->where('isDeleted', 0);
        $this->db->where('meetingId', $meetingId);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    
    /**
     * This function is used to update the meeting information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function updateOldmeeting($meetingInfo, $meetingId)
    {
        $this->db->where('meetingId', $meetingId);
        $this->db->update('ldg_meetings', $meetingInfo);
        
        return TRUE;
    }

    /**
     * This function is used to delete the meeting information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function deletemeeting($meetingId, $meetingInfo)
    {
        $this->db->where('meetingId', $meetingId);
        $this->db->update('ldg_meetings', $meetingInfo);
        
        return $this->db->affected_rows();
    }

    /**
     * This function is used to get all meeting sizes
     */
    function getmeetings()
    {
    	$this->db->select('meetingId, meetingNumber');
        $this->db->from('ldg_meetings');
        $this->db->where('isDeleted', 0);
        $query = $this->db->get();

        return $query->result();
    }
}