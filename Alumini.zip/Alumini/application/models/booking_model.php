<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Booking_model 
 * Booking model to handle database operations related to meeting booking.
 * @author : Dhairya Kapoor
 * @version : 1.1
 * @since : 19 Jan 2019
 */
class Booking_model extends CI_Model
{
    function bookingCount($searchText, $searchmeetingId, $searchconferenceId, $searchmeetingSizeId)
    {
        $this->db->select('BaseTbl.bookingId, BaseTbl.studentId, BaseTbl.bookingDtm, BaseTbl.meetingId,
                            BaseTbl.bookStartDate, BaseTbl.bookEndDate,
                            C.studentName, C.studentPhone, C.studentEmail,
                            R.meetingNumber, R.meetingSizeId, R.conferenceId, RS.sizeTitle, RS.sizeDescription,
                            F.conferenceName, F.conferenceCode');
        $this->db->from('ldg_bookings AS BaseTbl');
        $this->db->join('ldg_student AS C', 'BaseTbl.studentId = C.studentId');
        $this->db->join('ldg_meetings AS R', 'BaseTbl.meetingId = R.meetingId');
        $this->db->join('ldg_meeting_sizes AS RS', 'RS.sizeId = R.meetingSizeId', 'left');
        $this->db->join('ldg_conference AS F', 'F.conferenceId = R.conferenceId', 'left');
        $this->db->where('BaseTbl.isDeleted', 0);
        if(!empty($searchmeetingId)){
            $this->db->where('R.meetingId', $searchmeetingId);
        }
        if(!empty($searchmeetingSizeId)){
            $this->db->where('R.meetingSizeId', $searchmeetingSizeId);
        }
        if(!empty($searchconferenceId)){
            $this->db->where('R.conferenceId', $searchconferenceId);
        }
        $query = $this->db->get();
        
        return count($query->result());
    }

    function bookingListing($searchText, $searchmeetingId, $searchconferenceId, $searchmeetingSizeId, $page, $segment)
    {
        $this->db->select('BaseTbl.bookingId, BaseTbl.studentId, BaseTbl.bookingDtm, BaseTbl.meetingId,
                            BaseTbl.bookStartDate, BaseTbl.bookEndDate, BaseTbl.bookingComments,
                            C.studentName, C.studentPhone, C.studentEmail,
                            R.meetingNumber, R.meetingSizeId, R.conferenceId, RS.sizeTitle, RS.sizeDescription,
                            F.conferenceName, F.conferenceCode');
        $this->db->from('ldg_bookings AS BaseTbl');
        $this->db->join('ldg_student AS C', 'BaseTbl.studentId = C.studentId');
        $this->db->join('ldg_meetings AS R', 'BaseTbl.meetingId = R.meetingId');
        $this->db->join('ldg_meeting_sizes AS RS', 'RS.sizeId = R.meetingSizeId', 'left');
        $this->db->join('ldg_conference AS F', 'F.conferenceId = R.conferenceId', 'left');
        $this->db->where('BaseTbl.isDeleted', 0);
        if(!empty($searchmeetingId)){
            $this->db->where('R.meetingId', $searchmeetingId);
        }
        if(!empty($searchmeetingSizeId)){
            $this->db->where('R.meetingSizeId', $searchmeetingSizeId);
        }
        if(!empty($searchconferenceId)){
            $this->db->where('R.conferenceId', $searchconferenceId);
        }
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();
        return $result;
    }
}
