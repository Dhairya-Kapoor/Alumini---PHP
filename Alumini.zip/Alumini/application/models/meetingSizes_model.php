<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : meetingSizes_model 
 * meetingSizes model to handle database operations related to meeting sizes
 * @author : Dhairya Kapoor
 * @version : 1.1
 * @since : 12 Jan 2019
 */
class meetingSizes_model extends CI_Model
{
	/**
     * This function is used to get the conference listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function meetingSizeListingCount($searchText = '')
    {
        $this->db->select('BaseTbl.sizeId, BaseTbl.sizeTitle, BaseTbl.sizeDescription');
        $this->db->from('ldg_meeting_sizes as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.sizeDescription  LIKE '%".$searchText."%'
                            OR  BaseTbl.sizeTitle  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the conference listing
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function meetingSizeListing($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.sizeId, BaseTbl.sizeTitle, BaseTbl.sizeDescription');
        $this->db->from('ldg_meeting_sizes as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.sizeDescription  LIKE '%".$searchText."%'
                            OR  BaseTbl.sizeTitle  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new conference to system
     * @param array $conferenceInfo : This is conference information
     * @return number $insert_id : This is last inserted id
     */
    function addedNewmeetingSize($meetingSizeInfo)
    {
        $this->db->trans_start();
        $this->db->insert('ldg_meeting_sizes', $meetingSizeInfo);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        
        return $insert_id;
    }

    /**
     * This function used to get conference information by id
     * @param number $sizeId : This is conference id
     * @return array $result : This is conference information
     */
    function getmeetingSizeInfo($sizeId)
    {
        $this->db->select('sizeId, sizeTitle, sizeDescription');
        $this->db->from('ldg_meeting_sizes');
        $this->db->where('isDeleted', 0);
        $this->db->where('sizeId', $sizeId);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    
    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function updateOldmeetingSize($meetingSizeInfo, $sizeId)
    {
        $this->db->where('sizeId', $sizeId);
        $this->db->update('ldg_meeting_sizes', $meetingSizeInfo);
        
        return TRUE;
    }

    /**
     * This function is used to delete the user information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function deletemeetingSize($sizeId, $meetingSizeInfo)
    {
        $this->db->where('sizeId', $sizeId);
        $this->db->update('ldg_meeting_sizes', $meetingSizeInfo);
        
        return $this->db->affected_rows();
    }
}