<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : student_model 
 * User model to handle database operations related to users
 * @author : Dhairya Kapoor
 * @version : 1.1
 * @since : 18 January 2019
 */
class student_model extends CI_Model
{
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function studentListingCount($searchText = '')
    {
        $this->db->select('BaseTbl.studentId, BaseTbl.studentName, BaseTbl.studentAddress, BaseTbl.studentPhone, BaseTbl.studentEmail');
        $this->db->from('ldg_student as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.studentName  LIKE '%".$searchText."%'
                            OR  BaseTbl.studentAddress  LIKE '%".$searchText."%'
                            OR  BaseTbl.studentEmail  LIKE '%".$searchText."%'
                            OR  BaseTbl.studentPhone  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function studentListing($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.studentId, BaseTbl.studentName, BaseTbl.studentAddress, BaseTbl.studentPhone, BaseTbl.studentEmail');
        $this->db->from('ldg_student as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.studentName  LIKE '%".$searchText."%'
                            OR  BaseTbl.studentAddress  LIKE '%".$searchText."%'
                            OR  BaseTbl.studentEmail  LIKE '%".$searchText."%'
                            OR  BaseTbl.studentPhone  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }
    
    /**
     * This function is used to get the user roles information
     * @return array $result : This is result of the query
     */
    function getUserRoles()
    {
        $this->db->select('roleId, role');
        $this->db->from('ldg_roles');
        $this->db->where('roleId !=', 1);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    
    /**
     * This function is used to add new student to system
     * @return number $insert_id : This is last inserted id
     */
    function addNewstudent($studentInfo)
    {
        $this->db->trans_start();
        $this->db->insert('ldg_student', $studentInfo);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        return $insert_id;
    }
    
    /**
     * This function used to get user information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getstudentInfo($studentId)
    {
        $this->db->select('studentId, studentName, studentPhone, studentEmail, studentAddress, createdDtm');
        $this->db->from('ldg_student');
        $this->db->where('isDeleted', 0);
        $this->db->where('studentId', $studentId);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    
    /**
     * This function is used to update the student information
     * @param array $studentInfo : This is student updated information
     * @param number $studentId : This is student id
     */
    function updateOldstudent($studentInfo, $studentId)
    {
        $this->db->where('studentId', $studentId);
        $this->db->update('ldg_student', $studentInfo);
        
        return TRUE;
    }
    
    /**
     * This function is used to delete the user information
     * @param number $studentId : This is student id
     * @return boolean $result : TRUE / FALSE
     */
    function deletestudent($studentId, $studentInfo)
    {
        $this->db->where('studentId', $studentId);
        $this->db->update('ldg_student', $studentInfo);
        
        return $this->db->affected_rows();
    }
}