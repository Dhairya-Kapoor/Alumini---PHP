<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : conferences_model 
 * conferences model to handle database operations related to conferences
 * @author : Dhairya Kapoor
 * @version : 1.1
 * @since : 12 Jan 2019
 */
class conferences_model extends CI_Model
{	
	/**
     * This function is used to get the conference listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function conferencesListingCount($searchText = '')
    {
        $this->db->select('BaseTbl.conferenceId, BaseTbl.conferenceCode, BaseTbl.conferenceDescription, BaseTbl.conferenceName');
        $this->db->from('ldg_conference as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.conferenceCode  LIKE '%".$searchText."%'
                            OR  BaseTbl.conferenceName  LIKE '%".$searchText."%'
                            OR  BaseTbl.conferenceDescription  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();
        
        return count($query->result());
    }
    
    /**
     * This function is used to get the conference listing
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function conferencesListing($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.conferenceId, BaseTbl.conferenceCode, BaseTbl.conferenceDescription, BaseTbl.conferenceName');
        $this->db->from('ldg_conference as BaseTbl');
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.conferenceCode  LIKE '%".$searchText."%'
                            OR  BaseTbl.conferenceName  LIKE '%".$searchText."%'
                            OR  BaseTbl.conferenceDescription  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new conference to system
     * @param array $conferenceInfo : This is conference information
     * @return number $insert_id : This is last inserted id
     */
    function addedNewconference($conferenceInfo)
    {
        $this->db->trans_start();
        $this->db->insert('ldg_conference', $conferenceInfo);
        $insert_id = $this->db->insert_id();
        $this->db->trans_complete();
        
        return $insert_id;
    }

    /**
     * This function used to get conference information by id
     * @param number $conferenceId : This is conference id
     * @return array $result : This is conference information
     */
    function getconferenceInfo($conferenceId)
    {
        $this->db->select('conferenceId, conferenceName, conferenceCode, conferenceDescription');
        $this->db->from('ldg_conference');
        $this->db->where('isDeleted', 0);
        $this->db->where('conferenceId', $conferenceId);
        $query = $this->db->get();
        
        return $query->result();
    }
    
    
    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function updateOldconference($conferenceInfo, $conferenceId)
    {
        $this->db->where('conferenceId', $conferenceId);
        $this->db->update('ldg_conference', $conferenceInfo);
        
        return TRUE;
    }

    /**
     * This function is used to delete the user information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteconferences($conferencesId, $conferencesInfo)
    {
        $this->db->where('conferenceId', $conferencesId);
        $this->db->update('ldg_conference', $conferencesInfo);
        
        return $this->db->affected_rows();
    }
}