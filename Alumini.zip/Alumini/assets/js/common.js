/**
 * @author Dhairya Kapoor
 */


jQuery(document).ready(function(){
	
	jQuery(document).on("click", ".deleteUser", function(){
		var userId = $(this).data("userid"),
			hitURL = baseURL + "deleteUser",
			currentRow = $(this);
		
		var confirmation = confirm("Are you sure to delete this user ?");
		
		if(confirmation)
		{
			jQuery.ajax({
				type : "POST",
				dataType : "json",
				url : hitURL,
				data : { userId : userId } 
			}).done(function(data){
				console.log(data);
				currentRow.parents('tr').remove();
				if(data.status == true) { alert("User successfully deleted"); }
				else if(data.status == false) { alert("User deletion failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

	jQuery(document).on("click", ".deleteconferences", function(){
		var conferencesId = $(this).data("conferencesid"),
			hitURL = baseURL + "deleteconferences",
			currentRow = $(this);

		var confirmation = confirm("Are you sure to delete this conference ?");
		
		if(confirmation)
		{
			jQuery.ajax({
				type : "POST",
				dataType : "json",
				url : hitURL,
				data : { conferencesId : conferencesId } 
			}).done(function(data){
				currentRow.parents('tr').remove();
				if(data.status == true) { alert("conference successfully deleted"); }
				else if(data.status == false) { alert("conference deletion failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

	jQuery(document).on("click", ".deletemeetingSize", function(){
		var sizeId = $(this).data("meetingsizeid"),
			hitURL = baseURL + "deletemeetingSize",
			currentRow = $(this);
			
		var confirmation = confirm("Are you sure to delete this meeting Size ?");
		
		if(confirmation)
		{
			jQuery.ajax({
				type : "POST",
				dataType : "json",
				url : hitURL,
				data : { sizeId : sizeId } 
			}).done(function(data){
				currentRow.parents('tr').remove();
				if(data.status == true) { alert("meeting Size successfully deleted"); }
				else if(data.status == false) { alert("meeting Size deletion failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

	jQuery(document).on("click", ".deletemeeting", function(){
		var meetingId = $(this).data("meetingid"),
			hitURL = baseURL + "deletemeeting",
			currentRow = $(this);
			
		var confirmation = confirm("Are you sure to delete this meeting ?");
		
		if(confirmation)
		{
			jQuery.ajax({
				type : "POST",
				dataType : "json",
				url : hitURL,
				data : { meetingId : meetingId } 
			}).done(function(data){
				currentRow.parents('tr').remove();
				if(data.status == true) { alert("meeting successfully deleted"); }
				else if(data.status == false) { alert("meeting deletion failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

	jQuery(document).on("click", ".deleteBaseFare", function(){
		var bfId = $(this).data("bfid"),
			hitURL = baseURL + "deleteBaseFare",
			currentRow = $(this);
			
		var confirmation = confirm("Are you sure to delete this Base Fare ?");
		
		if(confirmation)
		{
			jQuery.ajax({
				type : "POST",
				dataType : "json",
				url : hitURL,
				data : { bfId : bfId } 
			}).done(function(data){
				currentRow.parents('tr').remove();
				if(data.status == true) { alert("meeting successfully deleted"); }
				else if(data.status == false) { alert("meeting deletion failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

	jQuery(document).on("click", ".deletestudent", function(){
		var studentId = $(this).data("studentid"),
			hitURL = baseURL + "deletestudent",
			currentRow = $(this);
			
		var confirmation = confirm("Are you sure to delete this student ?");
		
		if(confirmation)
		{
			jQuery.ajax({
				type : "POST",
				dataType : "json",
				url : hitURL,
				data : { studentId : studentId } 
			}).done(function(data){
				currentRow.parents('tr').remove();
				if(data.status == true) { alert("student successfully deleted"); }
				else if(data.status = false) { alert("student deletion failed"); }
				else { alert("Access denied..!"); }
			});
		}
	});

});
